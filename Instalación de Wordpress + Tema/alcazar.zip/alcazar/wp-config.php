<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'alcazar');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ':IOV#AH~rOp3XKXdX^mRskX~1+T5:(;3#OABk>$*``DzG}M`M$JbQjVC)oK&Bo]-');
define('SECURE_AUTH_KEY',  'CzTfvQGTn,R6CB{JV27:OzLU~}%[2yLDEzz0VPgOqg~P14),|,&>I20OI?WX(@&W');
define('LOGGED_IN_KEY',    'C[$pSJ_{O^X-mF-h%P^U>z}5z;F0*10qT44c?Y]q&VnlV?FW+&quIc+_flwd]v56');
define('NONCE_KEY',        'TW&D#].%P!8k4{c.!*5{L,4wpl$^qjrp;Y1))sMhoO^oK Yj#Qda3K!4v`|Q=!A8');
define('AUTH_SALT',        'iIBC#`kk+Bn/8;jnfEVQhH{Gna~`h(qE4kQw5Z /i]aBDkoD;P}r)|da.0yYGF o');
define('SECURE_AUTH_SALT', 't,_~t3V4#WgamewKkJSMn}>TMjG:EnEa80]Z_m[<#/aRD(gT+:t`}9B>fZL}VZ-?');
define('LOGGED_IN_SALT',   'XDYp$BHtwY?Aipo@aAFbF$,@.C6LB^x !)-5Y^Sd~YPgf-3<nw$=ww^nIkQ|IlD=');
define('NONCE_SALT',       'JOl`fYSJ9*rp^Uf}4/>,XI~&GF]DUcaL|Hgy]-<7*5YfEN:4^ZrD55`RXNRG%7.H');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
